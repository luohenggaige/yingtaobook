function test(){
	alert("test");
}