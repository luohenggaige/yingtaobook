package cn.luosong.util;

public interface ECPS_Constants {
	public static final String image_path = "http://localhost:8076/ds-images";
	public static final Integer PAGE_SIZE = 7;
}
